import Password from 'antd/es/input/Password';
import React, { useState } from 'react'
import { useNavigate, NavLink } from 'react-router-dom';
import { loginUser } from '../../userSlice';
import { useDispatch, useSelector } from 'react-redux';

const Changing_pwd = () => {
  const movePage = useNavigate();
  const [password, setPassword] = useState('');
  const [massage, setMassage] = useState('');

  const dispatch = useDispatch();
  const isLoggedIn = useSelector((state) => state.user.isLoggedIn);

  const pwdChange = (e) => {
    setPassword(e.target.value);
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    dispatch(loginUser({ password }));
  };

  if(isLoggedIn){
    return <NavLink to="/user/changing"/>
  }


  return (
    <div>
      <h2>비밀번호 확인</h2>
      <form onSubmit={handleSubmit}>
        <div>
          <label>비밀번호</label>
          <input type="password" value={password} onChange={pwdChange} />
        </div>
        <button type='submit'>확인</button>
        <button onClick={() => movePage('/user/mypage')}>취소</button>
      </form>
      <p>{massage}</p>
    </div>

  )
}

export default Changing_pwd
import React from 'react'

const AdminView_Item = () => {
  return (
    <div>AdminView_Item</div>
  )
}

export default AdminView_Item
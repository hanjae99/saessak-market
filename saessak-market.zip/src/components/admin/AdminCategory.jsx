import React from 'react'




const AdminCategory = () => {




  return (
    <div className='adminCategory'>AdminCategory</div>
  )
}

export default AdminCategory
import React from 'react'
import './MyPage.css'

const Header = () => {
  return (
    <div >
      <h1 className='header'>새싹마켓</h1>
    </div>
  )
}

export default Header 
import { NavLink, Route, Routes } from 'react-router-dom';
import './App.css';
import AdminPage from './components/admin/AdminPage';
import Header from './components/Header';
import Manu from './components/Manu';

const MainPage = () => {
  return (
    <div>
      <NavLink to='/admin'>관리자페이지</NavLink>
    </div>
  )
}


function App() {
  return (
    <div className='App'>
      {/* <Routes>
            <Route path='/admin/:page?' element={<AdminPage />} />
            <Route path='/*' element={<MainPage />} />
          </Routes> */}
      <Header></Header>
      <Manu></Manu>
    </div>
  );
}

export default App;

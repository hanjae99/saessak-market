import { createSlice } from "@reduxjs/toolkit";


const user = createSlice({
  name: "user",
  initialState: [
    {
      id: "admin",
      nickname: "관리자",
      pwd: "1111",
      name: "관리자",
      email: "saessak@gmail.com",
      phone: "01011112222",
      adress: "관악구",
      gender: "male",
    },
    {
      id: "koo",
      nickname: "구상모",
      pwd: "1111",
      name: "구상모",
      email: "koosangmo@gmail.com",
      phone: "01011112222",
      adress: "관악구",
      gender: "male",
    },
    {
      id: "jin",
      nickname: "김진",
      pwd: "1111",
      name: "김진",
      email: "kimjin@gmail.com",
      phone: "01011112222",
      adress: "관악구",
      gender: "male",
    },
    {
      id: "kgs",
      nickname: "김궁서",
      pwd: "1111",
      name: "김궁서",
      email: "kgs@gmail.com",
      phone: "01011112222",
      adress: "관악구",
      gender: "male",
    },
    {
      id: "lhj",
      nickname: "이한재",
      pwd: "1111",
      name: "이한재",
      email: "lhj@gmail.com",
      phone: "01011112222",
      adress: "관악구",
      gender: "male",
    },
    {
      id: "psh",
      nickname: "박상현",
      pwd: "1111",
      name: "박상현",
      email: "psh@gmail.com",
      phone: "01011112222",
      adress: "관악구",
      gender: "male",
    },
  ],
  reducers: {
    add: (state, action) => {
      state.push(action.payload);
      //action.payload에는 모든 initialState의 모든정보가 있어야한다.
    },
    delete: (state, action) => {
      //payload: id
      state = state.filter((e) => action.payload !== e.id);
    },
    update: (state, action) => {
      let newstate = {
        //payload: {name, nickname, pwd,email,phone,adress}
        name: action.payload.name,
        nickname: action.payload.nickname,
        pwd: action.payload.pwd,
        email: action.payload.email,
        phone: action.payload.phone,
        adress: action.payload.adress,
      };
      state = state.map((p) =>
        p.id === newstate.id ? { ...p, ...newstate } : p
      );
    },
    loginUser: (state, action) => {
      const {password} = action.payload;

      if(password === user.pwd){
        state.isLoggedIn = true;
        state.loginMessage = '성공';
      }else{
        state.isLoggedIn = false;
        state.loginMessage = '실패: 비밀번호가 올바르지 않습니다.';
      }
    }
  },
});

export const {loginUser} = user.actions;

export default user;

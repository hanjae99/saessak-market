# Used tools

React, HTML, CSS, JS

# Used Library

redux, react-redux, redux-toolkit, react-router-dom, react-icons, node-sass

# etc

node.js, yarn
